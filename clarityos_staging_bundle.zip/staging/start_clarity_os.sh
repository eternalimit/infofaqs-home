#!/bin/bash
echo "Starting ClarityOS v130..."
echo "Mode: Guest Mode"
echo "Watchdog Protocol: Active"
echo "Validating Kernel Integrity..."

if grep -q "STRIPPED" anti_stripped_kernel.txt; then
  echo "⚠️ Kernel integrity compromised. Aborting startup."
  exit 1
fi

echo "✓ Kernel secure. Loading InfoFAQs Engine..."
python3 fuse_responses.py &
echo "✓ Fusion Engine Ready"
echo "ClarityOS has launched successfully in Guest Mode."
