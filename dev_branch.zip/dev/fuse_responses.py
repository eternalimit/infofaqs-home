
import openai

def query_gpt(engine, prompt):
    response = openai.ChatCompletion.create(
        model=engine,
        messages=[{"role": "user", "content": prompt}]
    )
    return response['choices'][0]['message']['content']

def fuse_responses(question):
    clarity_response = query_gpt("gpt-4-turbo", question)
    mentor_response = query_gpt("custom-mentor-gpt", question)

    # Simple fusion logic
    fused = f"""
🔹 Clarity says:\n{clarity_response}\n
🔸 MentorGPT says:\n{mentor_response}\n
🧠 Summary:\n{summarize([clarity_response, mentor_response])}
"""
    return fused

def summarize(responses):
    combined = " ".join(responses)
    return query_gpt("gpt-4-turbo", f"Summarize and reconcile: {combined}")
