
# InfoFAQs Site Bundle – Deployment Guide

Welcome to the InfoFAQs Deployment Package. This bundle includes all you need to host and serve a structured FAQ system powered by GPT logic and semantic categorization.

## 📂 Contents

- `index.html` — Main homepage (Welcome + navigation)
- `echo_mining_dashboard.html` — Tailwind-based collapsible FAQ viewer
- `echo_mining_faq.md` — Markdown version for blogs or GitHub
- `updated_infofaqs_echo_mining.json` — Machine-readable FAQ JSON

## 🌐 Hosting Options

### Netlify (Recommended)
1. Visit https://app.netlify.com
2. Drag and drop the unzipped contents into the UI
3. Set a custom domain (e.g., infofaqs.com)
4. Done — HTTPS enabled by default

### GitHub Pages
1. Create a new repository (e.g., infofaqs-site)
2. Upload all files and commit
3. Go to Settings → Pages → Branch = `main`, folder = `/root`
4. Set your domain: infofaqs.com

### Vercel
1. Create a GitHub repo with these files
2. Import repo into https://vercel.com
3. Configure root as a static deployment

## 🛡️ API & Access Control

To enable `/faq` API:
- Use `updated_infofaqs_echo_mining.json` as backend
- Protect endpoints via API keys or JWT
- Public GET, Admin-only POST for injection

## 🧠 Optional Enhancements

- Deploy `autoload_infofaqs.patch` to automate FAQ ingestion
- Enable GPT-powered fusion using `fuse_responses()` logic
- Add analytics, logging, or search (e.g., Algolia)

## 📫 Contact

Site: [infofaqs.com](https://infofaqs.com)  
Admin: Richard Stein  
License: MIT

