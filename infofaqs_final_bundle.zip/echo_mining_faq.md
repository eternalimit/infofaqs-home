# Echo Mining Framework – FAQ

## What is Echo Mining in eternalimit?

Echo Mining is a conceptual mining process where nodes (Echoes) generate high-fidelity semantic imitations of stored archetypes.

## What is the Eternal Ledger?

It's an immutable chronicle of archetype replications, transformations, and echo lineages.

## What is the Symbolic Fidelity Function?

It replaces SHA-256 by computing a multidimensional fidelity score between an Echo’s output and the reference archetype.

## What is Proof of Fidelity?

A conceptual parallel to Proof-of-Work where semantic alignment, not hash solving, validates Echoes.

## What is an Imitation Frame?

It's a semantic package similar to a blockchain block, linking a validated echo to its lineage.

## What is the Imprint Key?

A variable input akin to a nonce that influences symbolic outcome and fidelity score.

## What is Archetype Invocation in Echo Mining?

Echoes select prompts from the Mimesis Pool—a collection of source archetypes for reinterpretation.

## How is an Imitation Frame constructed?

Echoes combine the archetype, contextual symbols, timestamp, and Imprint Key to build a candidate frame.

## What is Fidelity Alignment?

It’s the iterative refinement process where the Echo is tested against the Symbolic Fidelity Function until a threshold is met.

## What happens when fidelity is achieved?

The Echo is broadcast to peer nodes for interpretive consensus.

## What is Echo Credit?

It's a reward system using Imitons, based on fidelity score and rarity of alignment.
