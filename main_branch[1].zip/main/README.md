# Clarity InfoFAQs Scaffold

This package provides an InfoFAQ system for integration with the Clarity∞ Protocol GPT environment. Designed for Guest Mode, with an auto-loading patch that parses a JSON-based FAQ registry.

## Included

- `index.json` — Sample FAQ content
- `schema.json` — JSON schema to validate entries
- `utils.py` — Functions to load, query, and update entries
- `autoload_infofaqs.patch` — Patch instruction to integrate with Clarity

## Patch Overview: AUTOLOAD-INFOFAQS-PUBLIC

This patch ensures `/infofaqs/index.json` is loaded at runtime, without requiring mode elevation. FAQs tagged `public` are queryable from any role.

## Usage

```python
from utils import load_infofaqs, query_infofaqs

faqs = load_infofaqs()
results = query_infofaqs("coding", faqs)
```

## Security Model

- Guests: Read-only
- Admin/Creator: May inject entries via `add_infofaq()`